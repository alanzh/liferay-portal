﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'list', 'ko', {
	bulletedlist: '순서없는 목록',
	numberedlist: '순서있는 목록'
});
