﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'list', 'vi', {
	bulletedlist: 'Chèn/Xoá Danh sách không thứ tự',
	numberedlist: 'Chèn/Xoá Danh sách có thứ tự'
});
