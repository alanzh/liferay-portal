﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'list', 'mk', {
	bulletedlist: 'Insert/Remove Bulleted List', // MISSING
	numberedlist: 'Insert/Remove Numbered List' // MISSING
});
