﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'list', 'el', {
	bulletedlist: 'Εισαγωγή/Απομάκρυνση Λίστας Κουκκίδων',
	numberedlist: 'Εισαγωγή/Απομάκρυνση Αριθμημένης Λίστας'
});
