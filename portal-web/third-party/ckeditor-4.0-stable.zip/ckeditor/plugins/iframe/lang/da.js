﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'iframe', 'da', {
	border: 'Vis kant på rammen',
	noUrl: 'Venligst indsæt URL på iframen',
	scrolling: 'Aktiver scrollbars',
	title: 'Iframe egenskaber',
	toolbar: 'Iframe'
});
