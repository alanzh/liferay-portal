﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'iframe', 'vi', {
	border: 'Hiển thị viền khung',
	noUrl: 'Vui lòng nhập địa chỉ iframe',
	scrolling: 'Kích hoạt thanh cuộn',
	title: 'Thuộc tính iframe',
	toolbar: 'Iframe'
});
