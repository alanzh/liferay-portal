﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'iframe', 'et', {
	border: 'Raami äärise näitamine',
	noUrl: 'Vali iframe URLi liik',
	scrolling: 'Kerimisribade lubamine',
	title: 'IFrame omadused',
	toolbar: 'IFrame'
});
