﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'iframe', 'bn', {
	border: 'Show frame border', // MISSING
	noUrl: 'Please type the iframe URL', // MISSING
	scrolling: 'Enable scrollbars', // MISSING
	title: 'IFrame Properties', // MISSING
	toolbar: 'IFrame' // MISSING
});
