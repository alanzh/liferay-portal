﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'specialchar', 'it', {
	options: 'Opzioni carattere speciale',
	title: 'Seleziona carattere speciale',
	toolbar: 'Inserisci carattere speciale'
});
