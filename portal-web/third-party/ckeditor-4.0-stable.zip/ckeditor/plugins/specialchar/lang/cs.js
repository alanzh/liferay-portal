﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'specialchar', 'cs', {
	options: 'Nastavení speciálních znaků',
	title: 'Výběr speciálního znaku',
	toolbar: 'Vložit speciální znaky'
});
