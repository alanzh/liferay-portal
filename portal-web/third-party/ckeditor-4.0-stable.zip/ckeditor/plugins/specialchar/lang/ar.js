﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'specialchar', 'ar', {
	options: 'Special Character Options', // MISSING
	title: 'اختر الخواص',
	toolbar: 'إدراج  خاص.ِ'
});
