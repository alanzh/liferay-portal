﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'specialchar', 'zh', {
	options: 'Special Character Options', // MISSING
	title: '請選擇特殊符號',
	toolbar: '插入特殊符號'
});
