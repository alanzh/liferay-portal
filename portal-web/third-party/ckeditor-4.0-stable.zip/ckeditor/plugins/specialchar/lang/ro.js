﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'specialchar', 'ro', {
	options: 'Opțiuni caractere speciale',
	title: 'Selectează caracter special',
	toolbar: 'Inserează caracter special'
});
