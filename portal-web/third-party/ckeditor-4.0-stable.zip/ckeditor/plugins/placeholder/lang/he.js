﻿/**
 * @license Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.html or http://ckeditor.com/license
 */

CKEDITOR.plugins.setLang( 'placeholder', 'he', {
	title: 'מאפייני שומר מקום',
	toolbar: 'צור שומר מקום',
	text: 'תוכן שומר המקום',
	edit: 'ערוך שומר מקום',
	textMissing: 'שומר המקום חייב להכיל טקסט.'
});
