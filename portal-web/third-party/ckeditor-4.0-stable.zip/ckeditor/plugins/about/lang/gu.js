﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'gu', {
	copy: 'કોપીરાઈટ &copy; $1. ઓલ રાઈટ્સ ',
	dlgTitle: 'CKEditor વિષે',
	help: 'મદદ માટે $1 તપાસો',
	moreInfo: 'લાયસનસની માહિતી માટે અમારી વેબ સાઈટ',
	title: 'CKEditor વિષે',
	userGuide: 'CKEditor યુઝર્સ ગાઈડ'
});
