﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'pl', {
	copy: 'Copyright &copy; $1. Wszelkie prawa zastrzeżone.',
	dlgTitle: 'Informacje o programie CKEditor',
	help: 'Pomoc znajdziesz w $1.',
	moreInfo: 'Informacje na temat licencji można znaleźć na naszej stronie:',
	title: 'Informacje o programie CKEditor',
	userGuide: 'podręczniku użytkownika programu CKEditor'
});
