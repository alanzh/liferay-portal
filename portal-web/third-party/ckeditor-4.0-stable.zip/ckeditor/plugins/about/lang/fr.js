﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'fr', {
	copy: 'Copyright &copy; $1. Tous droits réservés.',
	dlgTitle: 'À propos de CKEditor',
	help: 'Consulter $1 pour l\'aide.',
	moreInfo: 'Pour les informations de licence, veuillez visiter notre site web:',
	title: 'À propos de CKEditor',
	userGuide: 'Guide de l\'utilisateur CKEditor en anglais'
});
