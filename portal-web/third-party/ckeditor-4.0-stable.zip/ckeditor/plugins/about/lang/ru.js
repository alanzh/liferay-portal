﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'about', 'ru', {
	copy: 'Copyright &copy; $1. Все права защищены.',
	dlgTitle: 'О CKEditor',
	help: '$1 содержит подробную справку по использованию.',
	moreInfo: 'Для получения информации о лицензии, пожалуйста, перейдите на наш сайт:',
	title: 'О CKEditor',
	userGuide: 'Руководство пользователя CKEditor'
});
