﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'pastetext', 'ca', {
	button: 'Enganxa com a text no formatat',
	title: 'Enganxa com a text no formatat'
});
