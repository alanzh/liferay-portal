﻿/*
Copyright (c) 2003-2012, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'pastetext', 'pt', {
	button: 'Colar como Texto Simples',
	title: 'Colar como Texto Simples'
});
